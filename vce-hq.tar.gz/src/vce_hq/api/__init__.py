"""FastAPI application layer."""
