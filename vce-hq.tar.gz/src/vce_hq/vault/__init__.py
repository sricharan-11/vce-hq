"""Credential management: The Vault."""
