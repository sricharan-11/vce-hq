"""Embedding service module."""
